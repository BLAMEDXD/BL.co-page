(function(){
  "use strict";

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduceMotion){ document.documentElement.classList.add('reduced-motion'); }

  /* ---------------------------------------------------------------------
     footer year
     --------------------------------------------------------------------- */
  document.querySelectorAll('[data-year]').forEach(function(el){
    el.textContent = new Date().getFullYear();
  });

  /* ---------------------------------------------------------------------
     nav scroll state + active link
     --------------------------------------------------------------------- */
  var nav = document.getElementById('siteNav');
  if(nav){
    function onScroll(){ nav.classList.toggle('scrolled', window.scrollY > 16); }
    window.addEventListener('scroll', onScroll, { passive:true });
    onScroll();
  }

  var here = (document.body.getAttribute('data-page') || '');
  document.querySelectorAll('.nav-link[data-page], .mobile-menu a[data-page]').forEach(function(a){
    if(a.getAttribute('data-page') === here){ a.classList.add('is-active'); }
  });

  /* ---------------------------------------------------------------------
     mobile menu
     --------------------------------------------------------------------- */
  var burger = document.getElementById('burgerBtn');
  var menu = document.getElementById('mobileMenu');
  if(burger && menu){
    function closeMenu(){
      burger.classList.remove('open'); menu.classList.remove('open');
      burger.setAttribute('aria-expanded','false'); document.body.style.overflow = '';
    }
    function toggleMenu(){
      var isOpen = menu.classList.toggle('open');
      burger.classList.toggle('open', isOpen);
      burger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      document.body.style.overflow = isOpen ? 'hidden' : '';
    }
    burger.addEventListener('click', toggleMenu);
    menu.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', closeMenu); });
    window.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeMenu(); });
  }

  /* ---------------------------------------------------------------------
     scroll reveal
     --------------------------------------------------------------------- */
  var revealEls = document.querySelectorAll('.reveal');
  if('IntersectionObserver' in window && !reduceMotion){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){ entry.target.classList.add('in-view'); io.unobserve(entry.target); }
      });
    }, { threshold:0.12, rootMargin:'0px 0px -64px 0px' });
    revealEls.forEach(function(el){ io.observe(el); });
  } else {
    revealEls.forEach(function(el){ el.classList.add('in-view'); });
  }

  /* ---------------------------------------------------------------------
     magnetic buttons (fine pointers only)
     --------------------------------------------------------------------- */
  var canHover = window.matchMedia('(pointer:fine)').matches;
  if(canHover && !reduceMotion){
    document.querySelectorAll('.magnetic').forEach(function(btn){
      btn.addEventListener('mousemove', function(e){
        var r = btn.getBoundingClientRect();
        var x = e.clientX - r.left - r.width/2;
        var y = e.clientY - r.top - r.height/2;
        btn.style.transform = 'translate(' + (x*0.14).toFixed(1) + 'px,' + (y*0.28).toFixed(1) + 'px)';
      });
      btn.addEventListener('mouseleave', function(){ btn.style.transform = ''; });
    });
  }

  /* ---------------------------------------------------------------------
     Lenis smooth scroll (progressive enhancement — CSS scroll-behavior
     already covers the no-JS / library-blocked case)
     --------------------------------------------------------------------- */
  var lenis = null;
  if(window.Lenis && !reduceMotion && canHover){
    try{
      lenis = new window.Lenis({ duration:1.05, smoothWheel:true, easing:function(t){ return 1 - Math.pow(1 - t, 3); } });
      function raf(time){ lenis.raf(time); requestAnimationFrame(raf); }
      requestAnimationFrame(raf);
      if(window.gsap){
        lenis.on('scroll', window.ScrollTrigger ? window.ScrollTrigger.update : function(){});
        window.gsap.ticker.add(function(time){ lenis.raf(time * 1000); });
        window.gsap.ticker.lagSmoothing(0);
      }
    } catch(e){ lenis = null; }
  }

  /* ---------------------------------------------------------------------
     Cinematic process timeline (GSAP + ScrollTrigger, with a graceful
     fallback to the plain scroll-reveal system if the libraries fail
     to load — e.g. blocked network, offline preview).
     --------------------------------------------------------------------- */
  var track = document.getElementById('processTrack');
  if(track){
    var fill = document.getElementById('processFill');
    var indicator = document.getElementById('processIndicator');
    var steps = Array.prototype.slice.call(track.querySelectorAll('.proc-step'));

    var hasGsap = window.gsap && window.ScrollTrigger && !reduceMotion;
    if(hasGsap){
      gsap.registerPlugin(ScrollTrigger);
      var tl = gsap.timeline({
        scrollTrigger:{ trigger:track, start:'top 78%', end:'bottom 65%', scrub:0.6 }
      });
      var segment = 100 / steps.length;
      steps.forEach(function(step, i){
        var target = segment * (i + 1);
        tl.to([fill, indicator], {
          duration:1,
          onUpdate:function(){
            var p = gsap.getProperty(fill, 'width', '%');
          }
        }, '>');
        tl.to(fill, { width:target + '%', ease:'none' }, '<');
        tl.to(indicator, { left:target + '%', ease:'none' }, '<');
        tl.call(function(){ step.classList.add('active'); }, null, '<+=0.7');
      });
    } else {
      /* fallback: reveal steps as the track scrolls into view */
      if('IntersectionObserver' in window){
        var io2 = new IntersectionObserver(function(entries){
          entries.forEach(function(entry){
            if(entry.isIntersecting){
              steps.forEach(function(s, i){ setTimeout(function(){ s.classList.add('active'); }, i * 160); });
              if(fill) fill.style.width = '100%';
              if(indicator) indicator.style.left = '100%';
              io2.unobserve(entry.target);
            }
          });
        }, { threshold:0.35 });
        io2.observe(track);
      } else {
        steps.forEach(function(s){ s.classList.add('active'); });
        if(fill) fill.style.width = '100%';
      }
    }
  }

  /* ---------------------------------------------------------------------
     Portfolio filter (Projects hub)
     --------------------------------------------------------------------- */
  var filterBar = document.querySelector('.filter-bar');
  if(filterBar){
    var chips = Array.prototype.slice.call(filterBar.querySelectorAll('.filter-chip'));
    var cards = Array.prototype.slice.call(document.querySelectorAll('[data-cat]'));
    function applyFilter(f){
      chips.forEach(function(c){ c.classList.toggle('active', c.getAttribute('data-filter') === f); });
      cards.forEach(function(card){
        var cats = (card.getAttribute('data-cat') || '').split(' ');
        var show = (f === 'all') || cats.indexOf(f) !== -1;
        card.style.display = show ? '' : 'none';
      });
    }
    chips.forEach(function(chip){
      chip.addEventListener('click', function(){ applyFilter(chip.getAttribute('data-filter')); });
    });
    /* deep link support: projects.html#filter=software */
    var hashMatch = window.location.hash.match(/filter=([a-z]+)/);
    if(hashMatch && chips.some(function(c){ return c.getAttribute('data-filter') === hashMatch[1]; })){
      applyFilter(hashMatch[1]);
    }
  }

  /* ---------------------------------------------------------------------
     Contact / newsletter forms — static demo, no backend wired up.
     Prevents a blind submit/reload and gives calm, honest feedback.
     --------------------------------------------------------------------- */
  document.querySelectorAll('form[data-demo-form]').forEach(function(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      var note = form.querySelector('[data-form-note]');
      if(note){
        note.textContent = 'This form is a design preview — connect it to your inbox or CRM to start receiving submissions.';
        note.style.color = 'var(--accent)';
      }
    });
  });

  /* =======================================================================
     ENGINEERING / INTERACTION LAYER
     ======================================================================= */

  /* ---- scroll progress bar ---- */
  var progressBar = document.createElement('div');
  progressBar.className = 'scroll-progress';
  document.body.appendChild(progressBar);
  function updateProgress(){
    var h = document.documentElement;
    var scrolled = h.scrollTop;
    var max = h.scrollHeight - h.clientHeight;
    progressBar.style.width = (max > 0 ? (scrolled / max) * 100 : 0) + '%';
  }
  window.addEventListener('scroll', updateProgress, { passive:true });
  updateProgress();

  /* ---- custom cursor (fine pointers only) ---- */
  if(canHover && !reduceMotion){
    document.documentElement.classList.add('has-cursor');
    var dot = document.createElement('div'); dot.className = 'cursor-dot';
    var ring = document.createElement('div'); ring.className = 'cursor-ring';
    var label = document.createElement('span'); label.className = 'cursor-label';
    ring.appendChild(label);
    document.body.appendChild(dot); document.body.appendChild(ring);

    var mx = 0, my = 0, rx = 0, ry = 0;
    window.addEventListener('mousemove', function(e){
      mx = e.clientX; my = e.clientY;
      dot.style.transform = 'translate(' + mx + 'px,' + my + 'px)';
    });
    (function loop(){
      rx += (mx - rx) * 0.18; ry += (my - ry) * 0.18;
      ring.style.transform = 'translate(' + rx + 'px,' + ry + 'px)';
      requestAnimationFrame(loop);
    })();

    var CURSOR_MAP = [
      { sel:'.pcard, .pcard-media', text:'View' },
      { sel:'.acard, .acard-media', text:'Read' },
      { sel:'.brand-row', text:'Explore' },
      { sel:'.div-card', text:'View' },
      { sel:'a, button, .filter-chip, summary', text:'' }
    ];
    document.addEventListener('mouseover', function(e){
      for(var i=0;i<CURSOR_MAP.length;i++){
        var m = e.target.closest(CURSOR_MAP[i].sel);
        if(m){
          ring.classList.add('is-active');
          label.textContent = CURSOR_MAP[i].text;
          return;
        }
      }
      ring.classList.remove('is-active');
      label.textContent = '';
    });
    document.addEventListener('mousedown', function(){ ring.classList.add('is-pressed'); });
    document.addEventListener('mouseup', function(){ ring.classList.remove('is-pressed'); });
    document.addEventListener('mouseleave', function(){ dot.style.opacity = '0'; ring.style.opacity = '0'; });
    document.addEventListener('mouseenter', function(){ dot.style.opacity = ''; ring.style.opacity = ''; });
  }

  /* ---- tilt + spotlight cards ---- */
  var tiltTargets = document.querySelectorAll('.div-card, .pcard, .culture-card, .value-card, .acard, .brand-row, .term-window');
  if(canHover && !reduceMotion){
    tiltTargets.forEach(function(card){
      card.classList.add('tilt-card');
      card.addEventListener('mousemove', function(e){
        var r = card.getBoundingClientRect();
        var px = ((e.clientX - r.left) / r.width) * 100;
        var py = ((e.clientY - r.top) / r.height) * 100;
        card.style.setProperty('--mx', px + '%');
        card.style.setProperty('--my', py + '%');
        card.classList.add('spotlight-on');
        var rotY = ((px - 50) / 50) * 1.4;
        var rotX = ((50 - py) / 50) * 1.4;
        /* inline transform overrides the CSS :hover lift, so the lift is
           reproduced here to keep both effects working together */
        card.style.transform = 'perspective(900px) translateY(-5px) rotateX(' + rotX.toFixed(2) + 'deg) rotateY(' + rotY.toFixed(2) + 'deg)';
      });
      card.addEventListener('mouseleave', function(){
        card.classList.remove('spotlight-on');
        card.style.transform = '';
      });
    });
  }

  /* ---- button press feedback (works alongside the magnetic offset) ---- */
  document.querySelectorAll('.btn').forEach(function(btn){
    btn.addEventListener('mousedown', function(){
      btn.classList.add('is-pressing');
      btn.style.transform = (btn.style.transform || '') + ' scale(.97)';
    });
    function release(){
      btn.classList.remove('is-pressing');
      btn.style.transform = (btn.style.transform || '').replace(' scale(.97)', '');
    }
    btn.addEventListener('mouseup', release);
    btn.addEventListener('mouseleave', release);
  });

  /* ---- count-up numbers ---- */
  var countEls = document.querySelectorAll('[data-countup]');
  if(countEls.length && 'IntersectionObserver' in window){
    var countIo = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(!entry.isIntersecting) return;
        var el = entry.target;
        var target = parseFloat(el.getAttribute('data-countup'));
        var pad = el.getAttribute('data-pad') === 'true';
        var start = null, duration = 1400;
        if(reduceMotion){ el.textContent = (pad ? String(target).padStart(2,'0') : target); countIo.unobserve(el); return; }
        function step(ts){
          if(!start) start = ts;
          var p = Math.min((ts - start) / duration, 1);
          var eased = 1 - Math.pow(1 - p, 3);
          var val = Math.round(eased * target);
          el.textContent = pad ? String(val).padStart(2,'0') : String(val);
          if(p < 1) requestAnimationFrame(step); else el.textContent = pad ? String(target).padStart(2,'0') : String(target);
        }
        requestAnimationFrame(step);
        countIo.unobserve(el);
      });
    }, { threshold:0.6 });
    countEls.forEach(function(el){ countIo.observe(el); });
  }

  /* ---- footer status strip (injected into every .footer) ---- */
  document.querySelectorAll('.footer').forEach(function(footer){
    var top = footer.querySelector('.footer-top');
    if(!top) return;
    var strip = document.createElement('div');
    strip.className = 'status-strip';
    strip.innerHTML =
      '<span class="status-pill"><span class="pulse-dot"></span>All Divisions Operational</span>' +
      '<span class="status-pill">Build Passing</span>' +
      '<span class="status-pill">5 Divisions Synced</span>';
    top.insertAdjacentElement('afterend', strip);
  });

  /* ---- FAQ: smooth JS-driven height (progressive enhancement over native <details>) ---- */
  document.querySelectorAll('.faq-item').forEach(function(item){
    var summary = item.querySelector('summary');
    var panel = item.querySelector('.faq-a');
    if(!summary || !panel) return;
    if(!item.open){ panel.style.height = '0px'; } else { panel.style.height = 'auto'; }
    summary.addEventListener('click', function(e){
      e.preventDefault();
      var isOpen = item.hasAttribute('open');
      if(isOpen){
        panel.style.height = panel.scrollHeight + 'px';
        requestAnimationFrame(function(){ panel.style.height = '0px'; });
        panel.addEventListener('transitionend', function te(){ item.removeAttribute('open'); panel.removeEventListener('transitionend', te); }, { once:true });
      } else {
        item.setAttribute('open','');
        panel.style.height = '0px';
        requestAnimationFrame(function(){ panel.style.height = panel.scrollHeight + 'px'; });
        panel.addEventListener('transitionend', function te(){ panel.style.height = 'auto'; panel.removeEventListener('transitionend', te); }, { once:true });
      }
    });
  });

  /* ---- terminal sequence (Nexus case study) ----
     Reveals each .term-line in order, preserving its inner markup (colored
     spans for prompt/ok/dim) rather than retyping raw text — a naive
     character-by-character retype would destroy that formatting. A blinking
     cursor lands on the final line once the sequence completes. */
  document.querySelectorAll('.term-window[data-typewriter]').forEach(function(term){
    var body = term.querySelector('.term-body');
    if(!body) return;
    var lines = Array.prototype.slice.call(body.querySelectorAll('.term-line'));
    var cursorEl = document.createElement('span'); cursorEl.className = 'term-cursor';
    var played = false;
    function play(){
      if(played) return; played = true;
      if(reduceMotion){
        lines.forEach(function(l){ l.classList.add('shown'); });
        lines[lines.length-1].appendChild(cursorEl);
        return;
      }
      var li = 0;
      function nextLine(){
        if(li >= lines.length){ lines[lines.length-1].appendChild(cursorEl); return; }
        lines[li].classList.add('shown');
        li++;
        setTimeout(nextLine, li === 1 ? 260 : 420);
      }
      nextLine();
    }
    if('IntersectionObserver' in window){
      var tio = new IntersectionObserver(function(entries){ entries.forEach(function(en){ if(en.isIntersecting){ play(); tio.unobserve(term); } }); }, { threshold:0.4 });
      tio.observe(term);
    } else { play(); }
  });

})();
